from enum import Enum


class RPS_Choices(Enum):
    rock = 0
    paper = 1
    scissors = 2