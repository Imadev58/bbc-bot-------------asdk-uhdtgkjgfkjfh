import discord
from discord.ext import commands
import config

class Bot_Admin(commands.Cog, name="Bot Admin"):
    """A set of commands only to be used by the bot creators."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    async def cog_load(self):
        print(f'{self.__class__.__name__} has been loaded.')

    @commands.Cog.listener()
    async def on_ready(self):
        pass

    @commands.command()
    @commands.guild_only()
    @commands.is_owner()
    async def sync(self, ctx: commands.Context):
        """
        Syncs all the commands to Discord.

        **Usage:** sync
        """
        # Try to sync the commands
        try:
            synced_global = await ctx.bot.tree.sync()
            sub_commands_count = len([subcommand.name for subcommand in self.bot.walk_commands() if subcommand.parent])

            embed = discord.Embed(
                title="Synchronization Complete",
                description=f"Synced {len(synced_global)} slash commands and {sub_commands_count} sub-commands globally.",
                timestamp=discord.utils.utcnow(),
                color=config.main_color
            )
            embed.set_footer(text=config.footer_text, icon_url=self.bot.user.avatar.url)
            await ctx.send(embed=embed)
        # If an error occurs then send the error
        except Exception as e:
            embed = discord.Embed(title='❌ ERROR',
                                  description=f'**The error occurred due to the following reasons.\n```{e}```',
                                  color=config.error_color)
            embed.set_footer(text=config.footer_text, icon_url=self.bot.user.avatar.url)
            await ctx.send(embed=embed)
            raise e

    @commands.command()
    @commands.guild_only()
    @commands.is_owner()
    async def update_prefix(self, ctx: commands.Context, new_prefix: str):
        """
        Updates the bot's command prefix.

        **Usage:** update_prefix [new_prefix]
        """
        try:
            # Update the prefix
            self.bot.command_prefix = commands.when_mentioned_or(new_prefix)
            # Notify the user
            await ctx.send(f"Prefix updated to `{new_prefix}`")
        except Exception as e:
            embed = discord.Embed(title='❌ ERROR',
                                  description=f'**The error occurred due to the following reasons.\n```{e}```',
                                  color=config.error_color)
            embed.set_footer(text=config.footer_text, icon_url=self.bot.user.avatar.url)
            await ctx.send(embed=embed)
            raise e

    @commands.command()
    @commands.guild_only()
    @commands.is_owner()
    async def reload_cog(self, ctx: commands.Context, cog_name: str):
        """
        Reloads a specified cog.

        **Usage:** reload_cog [cog_name]
        """
        try:
            self.bot.reload_extension(f"cogs.{cog_name}")
            await ctx.send(f"Cog `{cog_name}` reloaded successfully.")
        except Exception as e:
            embed = discord.Embed(title='❌ ERROR',
                                  description=f'**The error occurred due to the following reasons.\n```{e}```',
                                  color=config.error_color)
            embed.set_footer(text=config.footer_text, icon_url=self.bot.user.avatar.url)
            await ctx.send(embed=embed)
            raise e

    @commands.command()
    @commands.guild_only()
    @commands.is_owner()
    async def shutdown(self, ctx: commands.Context):
        """
        Shuts down the bot.

        **Usage:** shutdown
        """
        await ctx.send("Shutting down...")
        await self.bot.close()

    @commands.command()
    @commands.guild_only()
    @commands.is_owner()
    async def list_cogs(self, ctx: commands.Context):
        """
        Lists all loaded cogs.

        **Usage:** list_cogs
        """
        loaded_cogs = ', '.join([cog for cog in self.bot.cogs])
        await ctx.send(f"Loaded cogs: {loaded_cogs}")

    @commands.command()
    @commands.guild_only()
    @commands.is_owner()
    async def unload_cog(self, ctx: commands.Context, cog_name: str):
        """
        Unloads a specified cog.

        **Usage:** unload_cog [cog_name]
        """
        try:
            self.bot.unload_extension(f"cogs.{cog_name}")
            await ctx.send(f"Cog `{cog_name}` unloaded successfully.")
        except Exception as e:
            embed = discord.Embed(title='❌ ERROR',
                                  description=f'**The error occurred due to the following reasons.\n```{e}```',
                                  color=config.error_color)
            embed.set_footer(text=config.footer_text, icon_url=self.bot.user.avatar.url)
            await ctx.send(embed=embed)
            raise e

    @commands.command()
    @commands.guild_only()
    @commands.is_owner()
    async def help_admin(self, ctx: commands.Context):
        """
        Displays help for the bot admin commands.

        **Usage:** help_admin
        """
        help_message = """
        Here are the available bot admin commands:
        - `sync`: Syncs all the commands to Discord.
        - `update_prefix [new_prefix]`: Updates the bot's command prefix.
        - `reload_cog [cog_name]`: Reloads a specified cog.
        - `shutdown`: Shuts down the bot.
        - `list_cogs`: Lists all loaded cogs.
        - `unload_cog [cog_name]`: Unloads a specified cog.
        - `help_admin`: Displays help for the bot admin commands.
        """
        await ctx.send(help_message)

def setup(bot):
    bot.add_cog(Bot_Admin(bot))
