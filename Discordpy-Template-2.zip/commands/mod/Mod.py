# This script defines a Discord bot cog for handling security-related commands and tasks.

# Importing necessary modules from discord.ext and datetime
from discord.ext import commands
import discord
from datetime import datetime, timedelta

# Defining the Security cog class
class Security(commands.Cog):
    """A cog for handling security-related commands and tasks."""
    def __init__(self, bot):
        self.bot = bot

    # Command for initiating a security scan
    @commands.command(description="Initiates a security scan on the server.")
    async def scan(self, ctx):
        """Initiates a security scan on the server."""
        embed = discord.Embed(title="Security Scan Results", color=discord.Color.blurple())
        await self.check_recent_channel_creations(ctx, embed)
        await self.check_recent_role_creations(ctx, embed)
        await self.check_recent_bans_kicks(ctx, embed)
        await ctx.send(embed=embed)

    # Function to check for recent channel creations
    async def check_recent_channel_creations(self, ctx, embed):
        """Checks for recently created channels."""
        recent_channels = [channel.name for channel in ctx.guild.channels if isinstance(channel, discord.TextChannel) and (datetime.utcnow() - channel.created_at) <= timedelta(days=1)]
        if recent_channels:
            embed.add_field(name="Recent Channel Creations", value="\n".join(recent_channels), inline=False)

    # Function to check for recent role creations
    async def check_recent_role_creations(self, ctx, embed):
        """Checks for recently created roles."""
        recent_roles = [role.name for role in ctx.guild.roles if (datetime.utcnow() - role.created_at) <= timedelta(days=1)]
        if recent_roles:
            embed.add_field(name="Recent Role Creations", value="\n".join(recent_roles), inline=False)

    # Function to check for recent bans or kicks
    async def check_recent_bans_kicks(self, ctx, embed):
        """Checks for recently banned or kicked users."""
        bans = await ctx.guild.bans()
        recent_bans = [ban.user.name for ban in bans if (datetime.utcnow() - ban.user.created_at) <= timedelta(days=1)]
        if recent_bans:
            embed.add_field(name="Recent Bans", value="\n".join(recent_bans), inline=False)

    # Command for banning a member
    @commands.command(description="Bans a member from the server.")
    async def ban(self, ctx, user: commands.MemberConverter, reason="No reason provided"):
        """Bans a member from the server."""
        await ctx.guild.ban(user, reason=reason)
        embed = discord.Embed(description=f"{user} has been banned for {reason}.", color=discord.Color.green())
        await ctx.send(embed=embed)

    # Command for kicking a member
    @commands.command(description="Kicks a member from the server.")
    async def kick(self, ctx, user: commands.MemberConverter, reason="No reason provided"):
        """Kicks a member from the server."""
        await ctx.guild.kick(user, reason=reason)
        embed = discord.Embed(description=f"{user} has been kicked for {reason}.", color=discord.Color.green())
        await ctx.send(embed=embed)

    # Command for listing banned users
    @commands.command(description="Lists all banned users from the server.")
    async def banlist(self, ctx):
        """Lists all banned users from the server."""
        bans = await ctx.guild.bans()
        banned_users = [ban.user.name for ban in bans]
        embed = discord.Embed(title="Banned Users", description="\n".join(banned_users), color=discord.Color.blue())
        await ctx.send(embed=embed)

    # Command for unbanning a user
    @commands.command(description="Unbans a user from the server.")
    async def unban(self, ctx, user: str, reason="No reason provided"):
        """Unbans a user from the server."""
        banned_users = await ctx.guild.bans()
        for ban_entry in banned_users:
            if user.lower() in ban_entry.user.name.lower():
                await ctx.guild.unban(ban_entry.user, reason=reason)
                embed = discord.Embed(description=f"{ban_entry.user.name} has been unbanned.", color=discord.Color.green())
                await ctx.send(embed=embed)
                return
        embed = discord.Embed(description="User not found in ban list.", color=discord.Color.red())
        await ctx.send(embed=embed)

    # Command for listing kicked users
    @commands.command(description="Lists all users kicked from the server. (Under development)")
    async def listkicks(self, ctx):
        """Lists all users kicked from the server. (Under development)"""
        embed = discord.Embed(description="This feature is currently under development.", color=discord.Color.gold())
        await ctx.send(embed=embed)

# Function to set up the Security cog
def setup(bot):
    bot.add_cog(Security(bot))
