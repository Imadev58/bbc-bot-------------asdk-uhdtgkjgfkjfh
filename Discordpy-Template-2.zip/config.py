import random

footer_text = "hi"  # Footer text for all embeds

Default_Prefix = 'd.'  # Default prefix

main_color = 0x5865F2  # Main color for all EMBEDS, not Errors or Success usually...

error_color = 0xFF0000  # Error color for all errors

success_color = 0x00FF00  # Success color for all successful embeds

